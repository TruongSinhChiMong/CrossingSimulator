﻿using System.Collections;
using UnityEngine;

/// <summary>
/// Spawner tạo học sinh, cho chúng đi từ trong tường phải (spawnPosition)
/// ra điểm chờ bên phải (waitPointRight), sau đó nghe lệnh player.
/// Đồng thời cập nhật ProgressBarWorld và báo cho GameManager.
/// </summary>
public class StudentSpawner : MonoBehaviour
{
    [Header("Student Prefabs")]
    [SerializeField] private StudentController prefabTypeA;
    [SerializeField] private StudentController prefabTypeB;

    [Header("Spawn Settings")]
    [SerializeField] private int totalStudents = 6;
    [SerializeField] private Vector2 spawnPosition = new Vector2(4.5f, -2f);
    [SerializeField] private float minSpawnDelay = 0.5f;
    [SerializeField] private float maxSpawnDelay = 1.5f;

    [Header("Cross Settings")]
    [Tooltip("Mốc X bên trái được coi là đã qua đường (fallback nếu SafeZone không dùng).")]
    [SerializeField] private float leftGateX = -6.0f;
    [Tooltip("Điểm chờ bên phải, ngay sát vạch qua đường.")]
    [SerializeField] private Transform waitPointRight;

    [Header("Hierarchy")]
    [SerializeField] private Transform runtimeParent;

    [Header("UI / World UI")]
    [SerializeField] private SignCounter signCounter;
    [SerializeField] private ProgressBarWorld progressBar;

    private int spawnedCount;
    private int succeededCount;
    private int deadCount;

    private void Start()
    {
        spawnedCount = 0;
        succeededCount = 0;
        deadCount = 0;

        UpdateUI();
        StartCoroutine(SpawnRoutine());
    }

    private IEnumerator SpawnRoutine()
    {
        while (spawnedCount < totalStudents)
        {
            SpawnOneStudent();
            spawnedCount++;

            float delay = Random.Range(minSpawnDelay, maxSpawnDelay);
            yield return new WaitForSeconds(delay);
        }
    }

    private void SpawnOneStudent()
    {
        StudentController prefab = ChooseRandomPrefab();
        if (prefab == null)
        {
            Debug.LogWarning("[StudentSpawner] No student prefab assigned.");
            return;
        }

        Transform parent = runtimeParent != null ? runtimeParent : transform;
        Vector3 pos = spawnPosition; // trong tường phải

        StudentController stu = Instantiate(prefab, pos, Quaternion.identity, parent);

        Vector2 waitPoint = waitPointRight != null
            ? (Vector2)waitPointRight.position
            : spawnPosition;

        stu.SetupFromSpawner(leftGateX, waitPoint, this);

        UpdateUI();
    }

    private StudentController ChooseRandomPrefab()
    {
        if (prefabTypeA != null && prefabTypeB != null)
        {
            return Random.value < 0.5f ? prefabTypeA : prefabTypeB;
        }

        if (prefabTypeA != null) return prefabTypeA;
        if (prefabTypeB != null) return prefabTypeB;
        return null;
    }

    internal void NotifyStudentSucceeded(StudentController student)
    {
        succeededCount++;
        UpdateUI();

        if (GameManager.Instance != null)
        {
            GameManager.Instance.OnStudentSafe();
        }
    }

    internal void NotifyStudentDied(StudentController student)
    {
        deadCount++;
        UpdateUI();

        if (GameManager.Instance != null)
        {
            GameManager.Instance.OnStudentHit();
        }
    }

    private void UpdateUI()
    {
        int resolved = succeededCount + deadCount;
        int remaining = Mathf.Max(0, totalStudents - resolved);

        if (signCounter != null)
        {
            signCounter.SetRemaining(remaining);
        }

        if (progressBar != null)
        {
            progressBar.SetProgress(succeededCount, totalStudents);
        }
    }

    public int TotalStudents => totalStudents;
    public int SucceededStudents => succeededCount;
}
