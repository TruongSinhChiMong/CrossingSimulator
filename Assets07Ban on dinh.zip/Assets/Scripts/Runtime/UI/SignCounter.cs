﻿using TMPro;
using UnityEngine;

public class SignCounter : MonoBehaviour
{
    [SerializeField] private TextMeshProUGUI counterText;

    /// <summary>
    /// Cập nhật số học sinh còn lại trên bảng.
    /// </summary>
    public void SetRemaining(int remaining)
    {
        if (counterText != null)
        {
            counterText.text = remaining.ToString();
        }
    }
}
