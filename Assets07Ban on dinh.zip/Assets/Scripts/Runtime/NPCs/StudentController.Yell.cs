﻿using UnityEngine;

public partial class StudentController : MonoBehaviour
{
    private void UpdateYell(float deltaTime)
    {
        if (!enableAutoYell)
            return;

        if (isDead || hasReportedResult)
        {
            ResetYellState();
            return;
        }

        // chỉ la hét khi đang đứng chờ ở điểm A
        if (!reachedWaitPoint || isCrossing)
        {
            ResetYellState();
            return;
        }

        stoppedTimer += deltaTime;

        if (!hasYelledOnce)
        {
            if (stoppedTimer >= waitBeforeFirstYell)
            {
                TriggerYellAnimation();
                hasYelledOnce = true;
                yellTimer = 0f;
            }
        }
        else
        {
            yellTimer += deltaTime;
            if (yellTimer >= yellInterval)
            {
                TriggerYellAnimation();
                yellTimer = 0f;
            }
        }
    }

    private void TriggerYellAnimation()
    {
        if (animator != null)
        {
            animator.SetTrigger(AnimYell);
        }
    }
}
