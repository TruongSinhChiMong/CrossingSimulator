﻿using UnityEngine;

public partial class StudentController : MonoBehaviour
{
    private void OnEnable()
    {
        OrdersManager.OnCross += HandleCrossOrder;
        OrdersManager.OnStop += HandleStopOrder;
    }

    private void OnDisable()
    {
        OrdersManager.OnCross -= HandleCrossOrder;
        OrdersManager.OnStop -= HandleStopOrder;
    }

    private void HandleCrossOrder()
    {
        // chỉ học sinh chưa chết, chưa báo kết quả mới nghe lệnh
        if (isDead || hasReportedResult)
            return;

        // chưa tới điểm chờ A thì cũng chưa băng qua đường
        if (!reachedWaitPoint)
            return;

        isCrossing = true;
        isStopped = false;

        ResetYellState();

        if (animator != null)
        {
            animator.SetBool(AnimWalk, true);
            animator.ResetTrigger(AnimYell);
        }
    }

    private void HandleStopOrder()
    {
        if (isDead || hasReportedResult)
            return;

        if (!reachedWaitPoint)
            return;

        isStopped = true;
        isCrossing = false;
        currentVelocity = Vector2.zero;

        ResetYellState();

        if (animator != null)
        {
            animator.SetBool(AnimWalk, false);
            animator.SetTrigger(AnimYell);
        }
    }
}
