﻿using UnityEngine;

public partial class StudentController : MonoBehaviour
{
    private void Update()
    {
        // cập nhật logic la hét
        UpdateYell(Time.deltaTime);

        if (isDead)
        {
            currentVelocity = Vector2.zero;
            UpdateAnimatorByVelocity();
            return;
        }

        // 1) từ trong tường phải (S) đi ra điểm chờ A
        if (!reachedWaitPoint)
        {
            MoveFromSpawnToWaitPoint();
            return;
        }

        // 2) đã tới A nhưng chưa băng qua → đứng chờ / có thể la hét
        if (!isCrossing || isStopped)
        {
            currentVelocity = Vector2.zero;
            UpdateAnimatorByVelocity();
            return;
        }

        // 3) đang băng qua đường → đi sang trái
        currentVelocity = Vector2.left * moveSpeed;

        // fallback: nếu đi qua mốc X bên trái thì coi là thành công
        if (!hasReportedResult && transform.position.x <= leftGateX)
        {
            HandleReachedSafeZone(null);
        }

        UpdateAnimatorByVelocity();
    }

    private void FixedUpdate()
    {
        if (rb == null || isDead)
            return;

        rb.MovePosition(rb.position + currentVelocity * Time.fixedDeltaTime);
    }

    /// <summary>
    /// Di chuyển từ điểm spawn (S) trong tường đến điểm chờ A.
    /// </summary>
    private void MoveFromSpawnToWaitPoint()
    {
        Vector2 currentPos = transform.position;
        Vector2 targetPos = waitPointRight;

        float distance = Vector2.Distance(currentPos, targetPos);
        if (distance <= 0.02f)
        {
            transform.position = targetPos;
            currentVelocity = Vector2.zero;
            reachedWaitPoint = true;

            UpdateAnimatorByVelocity();
            return;
        }

        Vector2 dir = (targetPos - currentPos).normalized;
        currentVelocity = dir * moveSpeed;

        UpdateAnimatorByVelocity();
    }
}
