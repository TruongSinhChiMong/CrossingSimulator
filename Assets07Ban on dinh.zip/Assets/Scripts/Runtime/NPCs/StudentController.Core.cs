﻿using UnityEngine;

[RequireComponent(typeof(Rigidbody2D))]
[RequireComponent(typeof(Animator))]
public partial class StudentController : MonoBehaviour
{
    [Header("References")]
    [SerializeField] private Rigidbody2D rb;
    [SerializeField] private Animator animator;

    [Header("Movement")]
    [Tooltip("Tốc độ đi của học sinh.")]
    [SerializeField] private float moveSpeed = 2f;

    [Header("Tags")]
    [SerializeField] private string vehicleTag = "Vehicle";
    [SerializeField] private string safeZoneTag = "SafeZone";

    // --- STATE CHUNG ---
    // đi / dừng / chết
    private bool isCrossing;
    private bool isStopped;
    private bool isDead;

    // di chuyển hiện tại
    private Vector2 currentVelocity;

    // --- SPAWNER / MAP ---
    // mốc X được coi là đã qua đường (fallback nếu không dùng SafeZone)
    private float leftGateX;
    // điểm chờ bên phải (A)
    private Vector2 waitPointRight;
    // spawner đã tạo ra mình
    private StudentSpawner spawner;
    // đã tới điểm chờ A chưa
    private bool reachedWaitPoint;
    // đã báo kết quả (sống / chết) cho spawner chưa
    private bool hasReportedResult;

    // --- YELL (la hét) ---
    [Header("Yell Settings")]
    [SerializeField] private bool enableAutoYell = false;
    [SerializeField] private float waitBeforeFirstYell = 1.5f;
    [SerializeField] private float yellInterval = 3f;

    private bool hasYelledOnce;
    private float stoppedTimer;
    private float yellTimer;

    // Animator params
    private static readonly int AnimWalk = Animator.StringToHash("Walk");
    private static readonly int AnimYell = Animator.StringToHash("Yell");
    private static readonly int AnimDie = Animator.StringToHash("Die");

    private void Reset()
    {
        rb = GetComponent<Rigidbody2D>();
        animator = GetComponent<Animator>();
    }

    private void Awake()
    {
        if (rb == null) rb = GetComponent<Rigidbody2D>();
        if (animator == null) animator = GetComponent<Animator>();

        ResetCoreState();
        ResetYellState();
    }

    private void ResetCoreState()
    {
        isCrossing = false;
        isStopped = false;
        isDead = false;
        hasReportedResult = false;
        reachedWaitPoint = false;
        currentVelocity = Vector2.zero;
    }

    private void ResetYellState()
    {
        hasYelledOnce = false;
        stoppedTimer = 0f;
        yellTimer = 0f;
    }

    private void UpdateAnimatorByVelocity()
    {
        if (animator == null) return;

        bool walking = !isDead && currentVelocity.sqrMagnitude > 0.001f;
        animator.SetBool(AnimWalk, walking);
    }
}
