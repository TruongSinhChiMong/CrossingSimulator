﻿using System.Collections;
using UnityEngine;

/// <summary>
/// Spawner tạo học sinh theo thời gian, báo về ProgressBarWorld khi có học sinh qua đường thành công.
/// </summary>
public class StudentSpawner : MonoBehaviour
{
    [Header("Student Prefabs")]
    [Tooltip("Prefab học sinh loại A (Student_TypeA).")]
    [SerializeField] private StudentController prefabTypeA;

    [Tooltip("Prefab học sinh loại B (Student_TypeB).")]
    [SerializeField] private StudentController prefabTypeB;

    [Header("Spawn Settings")]
    [Tooltip("Tổng số học sinh sẽ spawn trong map này.")]
    [SerializeField] private int totalStudents = 6;

    [Tooltip("Vị trí spawn (X,Y) trong world.")]
    [SerializeField] private Vector2 spawnPosition = new Vector2(4f, -2.2f);

    [SerializeField] private float minSpawnDelay = 3f;
    [SerializeField] private float maxSpawnDelay = 8f;

    [Header("Gates & Wait Points")]
    [Tooltip("X của mép bên trái (khi nhỏ hơn giá trị này coi như đã qua đường).")]
    [SerializeField] private float leftGateX = -2.3f;

    [Tooltip("Điểm chờ bên phải (cạnh player).")]
    [SerializeField] private Transform waitPointRight;

    [Header("Progress (Sprite Bar)")]
    [Tooltip("Tham chiếu tới ProgressBar_World trong scene.")]
    [SerializeField] private ProgressBarWorld progressBar;

    [Header("Hierarchy (Runtime Parenting)")]
    [Tooltip("Tất cả học sinh sinh ra sẽ được set parent vào đây (ví dụ object Runtime).")]
    [SerializeField] private Transform runtimeParent;

    // runtime
    private int spawnedCount;
    private int succeededCount;

    private void Start()
    {
        spawnedCount = 0;
        succeededCount = 0;
        UpdateProgressBar();
        StartCoroutine(SpawnLoop());
    }

    private IEnumerator SpawnLoop()
    {
        while (spawnedCount < totalStudents)
        {
            SpawnOneStudent();
            spawnedCount++;

            float delay = Random.Range(minSpawnDelay, maxSpawnDelay);
            yield return new WaitForSeconds(delay);
        }
    }

    private void SpawnOneStudent()
    {
        StudentController prefab = null;

        if (prefabTypeA != null && prefabTypeB != null)
        {
            prefab = (Random.value < 0.5f) ? prefabTypeA : prefabTypeB;
        }
        else if (prefabTypeA != null)
        {
            prefab = prefabTypeA;
        }
        else if (prefabTypeB != null)
        {
            prefab = prefabTypeB;
        }

        if (prefab == null)
        {
            Debug.LogWarning("[StudentSpawner] Không có prefab nào được gán!");
            return;
        }

        Vector3 pos = new Vector3(spawnPosition.x, spawnPosition.y, 0f);
        Quaternion rot = Quaternion.identity;

        Transform parent = runtimeParent != null ? runtimeParent : null;
        StudentController instance = Instantiate(prefab, pos, rot, parent);

        Vector2 waitRight = waitPointRight != null
            ? (Vector2)waitPointRight.position
            : spawnPosition;

        // Gửi thông tin cho StudentController
        instance.SetupFromSpawner(leftGateX, waitRight, this);
    }

    internal void NotifyStudentSucceeded(StudentController student)
    {
        succeededCount++;
        UpdateProgressBar();
    }

    internal void NotifyStudentDied(StudentController student)
    {
        // Nếu muốn chết cũng tính vào tiến độ thì mở dòng dưới.
        // succeededCount++;

        UpdateProgressBar();
    }

    private void UpdateProgressBar()
    {
        if (progressBar != null)
        {
            progressBar.SetProgress(succeededCount, totalStudents);
        }
    }

    // Cho chỗ khác đọc nếu cần
    public int TotalStudents => totalStudents;
    public int SucceededStudents => succeededCount;
}
