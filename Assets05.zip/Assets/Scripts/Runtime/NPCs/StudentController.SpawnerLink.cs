﻿using UnityEngine;

public partial class StudentController : MonoBehaviour
{
    // ---- THÔNG TIN DO SPAWNER TRUYỀN VÀO ----
    private float leftGateX;
    private Vector2 waitPointRight;
    private StudentSpawner spawner;

    // Đã báo kết quả (sống/chết) cho spawner chưa?
    private bool hasReportedResult;

    /// <summary>
    /// Gọi ngay sau khi Instantiate từ StudentSpawner.
    /// </summary>
    public void SetupFromSpawner(float leftGateX, Vector2 waitPointRight, StudentSpawner spawner)
    {
        this.leftGateX = leftGateX;
        this.waitPointRight = waitPointRight;
        this.spawner = spawner;

        // Đặt vị trí đứng chờ bên phải
        transform.position = waitPointRight;

        // Reset toàn bộ state
        ResetCoreState();
        ResetYellState();
        hasReportedResult = false;
    }

    /// <summary>
    /// Học sinh đã qua cổng trái / vùng an toàn (thành công).
    /// Được gọi từ Movement (theo X) hoặc từ Collisions (SafeZone trigger).
    /// </summary>
    private void HandleReachedLeftGate()
    {
        if (hasReportedResult || isDead)
            return;

        hasReportedResult = true;
        isCrossing = false;
        isStopped = false;
        currentVelocity = Vector2.zero;

        ResetYellState();

        if (animator != null)
        {
            animator.SetBool(AnimWalk, false);
        }

        if (spawner != null)
        {
            spawner.NotifyStudentSucceeded(this);
        }
    }

    /// <summary>
    /// Học sinh bị xe tông (chết).
    /// Được gọi từ Collisions.
    /// </summary>
    private void HandleHitByVehicle()
    {
        if (hasReportedResult)
            return;

        hasReportedResult = true;
        isDead = true;
        isCrossing = false;
        isStopped = false;
        currentVelocity = Vector2.zero;

        ResetYellState();

        if (animator != null)
        {
            animator.SetBool(AnimWalk, false);
            animator.SetTrigger(AnimDie);
        }

        if (spawner != null)
        {
            spawner.NotifyStudentDied(this);
        }
    }
}
