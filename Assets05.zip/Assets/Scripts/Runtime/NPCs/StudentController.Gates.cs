﻿using UnityEngine;

public partial class StudentController : MonoBehaviour
{
    /// <summary>
    /// Cho phép script khác (không phải Spawner) cấu hình cổng trái.
    /// Thực tế StudentSpawner đã set giá trị này thông qua SetupFromSpawner.
    /// </summary>
    public void SetLeftGateX(float x)
    {
        leftGateX = x;
    }
}
