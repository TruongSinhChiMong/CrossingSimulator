﻿using UnityEngine;

public partial class StudentController : MonoBehaviour
{
    [Header("Yell Settings")]
    [Tooltip("Bật/tắt hệ thống tự la hét sau khi chờ quá lâu.")]
    [SerializeField] private bool enableAutoYell = false;

    [Tooltip("Thời gian đứng chờ trước khi la hét lần đầu.")]
    [SerializeField] private float waitBeforeFirstYell = 1.5f;

    [Tooltip("Khoảng cách giữa các lần la hét tiếp theo (nếu còn đứng chờ).")]
    [SerializeField] private float yellInterval = 3f;

    // runtime yell state
    private bool hasYelledOnce;
    private float stoppedTimer;
    private float yellTimer;

    /// <summary>
    /// Reset toàn bộ state liên quan Yell.
    /// Gọi từ Core (khi spawn) và từ Orders/SpawnerLink.
    /// </summary>
    private void ResetYellState()
    {
        hasYelledOnce = false;
        stoppedTimer = 0f;
        yellTimer = 0f;
    }

    /// <summary>
    /// Gọi mỗi frame (từ Movement) để xử lý auto-yell khi đứng chờ.
    /// </summary>
    private void UpdateYell(float deltaTime)
    {
        if (!enableAutoYell)
            return;

        // nếu đang đi hoặc đã chết / đã báo kết quả → không Yell nữa
        if (isDead || hasReportedResult || isCrossing)
        {
            ResetYellState();
            return;
        }

        // chỉ quan tâm khi đứng chờ / bị stop
        stoppedTimer += deltaTime;

        if (!hasYelledOnce)
        {
            if (stoppedTimer >= waitBeforeFirstYell)
            {
                TriggerYellAnimation();
                hasYelledOnce = true;
                yellTimer = 0f;
            }
        }
        else
        {
            // đã hét ít nhất 1 lần, tiếp tục lặp theo interval
            yellTimer += deltaTime;
            if (yellTimer >= yellInterval)
            {
                TriggerYellAnimation();
                yellTimer = 0f;
            }
        }
    }

    /// <summary>
    /// Gọi chỗ nào cần chơi anim Yell (Stop order + AutoYell).
    /// </summary>
    private void TriggerYellAnimation()
    {
        if (animator != null)
        {
            animator.SetTrigger(AnimYell);
        }
    }
}
