﻿using UnityEngine;

public partial class StudentController : MonoBehaviour
{
    private void Update()
    {
        // Cập nhật logic la hét mỗi frame
        UpdateYell(Time.deltaTime);

        if (isDead)
        {
            currentVelocity = Vector2.zero;
            UpdateAnimatorByVelocity();
            return;
        }

        // Nếu chưa được ra lệnh Cross hoặc đang bị Stop → đứng yên
        if (!isCrossing || isStopped)
        {
            currentVelocity = Vector2.zero;
            UpdateAnimatorByVelocity();
            return;
        }

        // Đang băng qua → đi sang trái
        currentVelocity = Vector2.left * moveSpeed;

        // Nếu dùng mốc toạ độ X để đánh dấu “qua cổng trái”
        if (transform.position.x <= leftGateX)
        {
            HandleReachedLeftGate();
        }

        UpdateAnimatorByVelocity();
    }

    private void FixedUpdate()
    {
        if (rb == null) return;

        rb.MovePosition(rb.position + currentVelocity * Time.fixedDeltaTime);
    }
}
