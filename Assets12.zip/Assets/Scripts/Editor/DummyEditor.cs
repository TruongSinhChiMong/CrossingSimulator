﻿#if UNITY_EDITOR
using UnityEditor;

public static class DummyEditor
{
    // Chỉ để Unity tạo Assembly-CSharp-Editor
}
#endif
