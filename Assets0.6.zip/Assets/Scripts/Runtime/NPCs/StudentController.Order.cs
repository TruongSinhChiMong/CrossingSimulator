using UnityEngine;

public partial class StudentController : MonoBehaviour
{
    private void OnEnable()
    {
        OrdersManager.OnCross += HandleCrossOrder;
        OrdersManager.OnStop += HandleStopOrder;
    }

    private void OnDisable()
    {
        OrdersManager.OnCross -= HandleCrossOrder;
        OrdersManager.OnStop -= HandleStopOrder;
    }

    /// <summary>
    /// L?nh Z - Cross: cho ph��p h?c sinh b?ng qua.
    /// </summary>
    private void HandleCrossOrder()
    {
        if (isDead || hasReportedResult)
            return;

        isCrossing = true;
        isStopped = false;

        // Reset logic Yell v�� ?? c�� l?nh m?i
        ResetYellState();

        if (animator != null)
        {
            animator.SetBool(AnimWalk, true);
            animator.ResetTrigger(AnimYell);
        }
    }

    /// <summary>
    /// L?nh X - Stop: d?ng t?i ch?, la h��t.
    /// </summary>
    private void HandleStopOrder()
    {
        if (isDead || hasReportedResult)
            return;

        isStopped = true;
        isCrossing = false;
        currentVelocity = Vector2.zero;

        // Khi Stop, reset timer Yell v�� cho h��t 1 ph��t
        ResetYellState();
        TriggerYellAnimation();

        if (animator != null)
        {
            animator.SetBool(AnimWalk, false);
        }
    }
}
