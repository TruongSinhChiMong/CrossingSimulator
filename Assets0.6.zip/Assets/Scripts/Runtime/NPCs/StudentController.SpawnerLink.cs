﻿using UnityEngine;

public partial class StudentController : MonoBehaviour
{
    // ----- Thông tin từ Spawner -----
    private float leftGateX;
    private Vector2 waitPointRight;
    private StudentSpawner spawner;

    // Đã đi tới điểm chờ bên phải chưa?
    private bool reachedWaitPoint;

    // Đã báo kết quả (sống/chết) cho Spawner chưa?
    private bool hasReportedResult;

    /// <summary>
    /// Gọi ngay sau khi Instantiate từ StudentSpawner.
    /// LƯU Ý: Không đổi vị trí ở đây, để giữ vị trí spawn (S) trong tường.
    /// </summary>
    public void SetupFromSpawner(float leftGateX, Vector2 waitPointRight, StudentSpawner spawner)
    {
        this.leftGateX = leftGateX;
        this.waitPointRight = waitPointRight;
        this.spawner = spawner;

        // reset state
        isCrossing = false;
        isStopped = false;
        isDead = false;
        hasReportedResult = false;
        reachedWaitPoint = false;
        currentVelocity = Vector2.zero;

        ResetYellState();

        if (animator != null)
        {
            animator.SetBool(AnimWalk, false);
            animator.ResetTrigger(AnimYell);
        }

        if (rb != null)
        {
            rb.simulated = true; // cho physics hoạt động lại nếu reuse
        }
    }

    /// <summary>
    /// Student đã tới vùng an toàn bên trái (qua đường thành công).
    /// Được gọi từ Movement (check X) hoặc Collision (SafeZone trigger).
    /// </summary>
    private void HandleReachedLeftGate()
    {
        if (hasReportedResult)
            return;

        hasReportedResult = true;
        isCrossing = false;
        isStopped = false;
        currentVelocity = Vector2.zero;

        ResetYellState();

        if (animator != null)
        {
            animator.SetBool(AnimWalk, false);
        }

        if (spawner != null)
        {
            spawner.NotifyStudentSucceeded(this);
        }
    }

    /// <summary>
    /// Student bị xe tông.
    /// </summary>
    private void HandleHitByVehicle()
    {
        if (hasReportedResult)
            return;

        hasReportedResult = true;
        isDead = true;
        isCrossing = false;
        isStopped = false;
        currentVelocity = Vector2.zero;

        ResetYellState();

        if (animator != null)
        {
            animator.SetBool(AnimWalk, false);
            animator.SetTrigger(AnimDie);
        }

        // Tắt physics + collider để không bị xe đẩy đi
        if (rb != null)
        {
            rb.simulated = false;
        }
        var col = GetComponent<Collider2D>();
        if (col != null)
        {
            col.enabled = false;
        }

        if (spawner != null)
        {
            spawner.NotifyStudentDied(this);
        }
    }
}
