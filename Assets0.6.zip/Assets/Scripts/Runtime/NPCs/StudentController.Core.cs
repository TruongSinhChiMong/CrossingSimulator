﻿using UnityEngine;

[RequireComponent(typeof(Rigidbody2D))]
[RequireComponent(typeof(Animator))]
public partial class StudentController : MonoBehaviour
{
    [Header("References")]
    [SerializeField] private Rigidbody2D rb;
    [SerializeField] private Animator animator;

    [Header("Movement")]
    [Tooltip("Tốc độ đi ngang sang trái khi băng qua đường.")]
    [SerializeField] private float moveSpeed = 2f;

    [Header("Collision Tags")]
    [Tooltip("Tag dùng cho xe (Vehicle).")]
    [SerializeField] private string vehicleTag = "Vehicle";

    [Tooltip("Tag dùng cho vùng an toàn (SafeZone).")]
    [SerializeField] private string safeZoneTag = "SafeZone";

    // ---- CORE STATE ----
    // đúng spec mới: isCrossing / isStopped / isDead
    private bool isCrossing;          // đang băng qua
    private bool isStopped;           // đang bị lệnh dừng
    private bool isDead;              // bị xe tông / không còn hoạt động

    // Vận tốc hiện tại (dùng cho Rigidbody2D)
    private Vector2 currentVelocity;

    // Animator parameter IDs
    private static readonly int AnimWalk = Animator.StringToHash("Walk");
    private static readonly int AnimYell = Animator.StringToHash("Yell");
    private static readonly int AnimDie = Animator.StringToHash("Die");

    private void Reset()
    {
        rb = GetComponent<Rigidbody2D>();
        animator = GetComponent<Animator>();
    }

    private void Awake()
    {
        if (rb == null) rb = GetComponent<Rigidbody2D>();
        if (animator == null) animator = GetComponent<Animator>();

        ResetCoreState();
    }

    /// <summary>
    /// Reset lại trạng thái cốt lõi (Move/Dead).
    /// Được dùng khi spawn mới hoặc reuse.
    /// </summary>
    private void ResetCoreState()
    {
        isCrossing = false;
        isStopped = false;
        isDead = false;
        currentVelocity = Vector2.zero;

        if (animator != null)
        {
            animator.SetBool(AnimWalk, false);
        }
    }

    /// <summary>
    /// Helper cập nhật bool Walk theo currentVelocity và isDead.
    /// </summary>
    private void UpdateAnimatorByVelocity()
    {
        if (animator == null) return;

        bool walking = !isDead && currentVelocity.sqrMagnitude > 0.001f;
        animator.SetBool(AnimWalk, walking);
    }
}
