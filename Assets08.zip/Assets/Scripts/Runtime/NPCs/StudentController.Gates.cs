﻿using UnityEngine;

public partial class StudentController : MonoBehaviour
{
    public void SetLeftGateX(float x)
    {
        leftGateX = x;
    }
}
