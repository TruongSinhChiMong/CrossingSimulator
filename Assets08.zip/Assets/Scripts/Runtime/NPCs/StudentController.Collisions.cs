﻿using UnityEngine;

public partial class StudentController : MonoBehaviour
{
    private void OnTriggerEnter2D(Collider2D other)
    {
        if (isDead || hasReportedResult)
            return;

        if (!string.IsNullOrEmpty(vehicleTag) && other.CompareTag(vehicleTag))
        {
            HandleHitByVehicle(other);
            return;
        }

        if (!string.IsNullOrEmpty(safeZoneTag) && other.CompareTag(safeZoneTag))
        {
            HandleReachedSafeZone(other);
            return;
        }
    }
}
