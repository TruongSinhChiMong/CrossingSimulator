﻿using TMPro;
using UnityEngine;

public class SignCounter : MonoBehaviour
{
    [SerializeField] private TextMeshProUGUI counterText;

    /// <summary>
    /// Hàm chung để set bất kỳ con số nào lên biển báo.
    /// </summary>
    public void SetNumber(int value)
    {
        if (counterText != null)
            counterText.text = value.ToString();
    }

    /// <summary>
    /// Giữ lại tên cũ cho các chỗ đang gọi SetRemaining().
    /// Thực chất chỉ gọi lại SetNumber cho tiện.
    /// </summary>
    public void SetRemaining(int remaining)
    {
        SetNumber(remaining);
    }
}
